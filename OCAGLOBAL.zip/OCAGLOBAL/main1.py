# main.py
# Punto de entrada del programa

from interfaz import main

if __name__ == "__main__":
    main()

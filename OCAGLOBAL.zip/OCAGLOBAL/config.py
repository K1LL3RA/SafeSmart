# config.py
# Archivo de configuración centralizada para las variables del sistema
# Datos de conexión a la base de datos SQL Server
server = '40.75.98.215'
database = 'SafeSmart_Checklist'
username = 'jarbildo_dev'
password = 'oca$2022'

# Ruta fija a la plantilla de Excel base (puedes hacerla seleccionable desde la GUI si deseas)
plantilla_path = 'C:/Users/user/Desktop/OCAGLOBAL/base.xlsx'
